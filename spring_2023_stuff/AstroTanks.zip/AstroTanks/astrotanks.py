############ Def ###########
import pygame
import numpy as np
import time
import random

pygame.init()
display_width, display_height = 800, 600

gameDisplay = pygame.display.set_mode((display_width, display_height))

fire_sound = pygame.mixer.Sound("boom.wav")
explosion_sound = pygame.mixer.Sound("explosin.wav")
pygame.mixer.music.load('starwars.mp3')
pygame.mixer.music.set_volume(0.5)

white = (255,255,255)
black = (0,0,0)
blue = 	(random.randint(100,255), random.randint(100,255), random.randint(100,255))

red = (200,0,0)
light_red = (255,0,0)

yellow = (200,200,0)
light_yellow = (255,255,0)

green = (34,177,76)
light_green = (0,255,0)

clock = pygame.time.Clock()

ground_height = 35

smallfont = pygame.font.SysFont("couriernew", 25)
medfont = pygame.font.SysFont("couriernew", 50)
largefont = pygame.font.SysFont("couriernew", 70)


##### classes ##########

class Vector:
    def __init__(self, x, y):
        self.x = x
        self.y = y
    def len(self):
        return np.sqrt(self.x**2 + self.y**2)
    def __add__(self, other):
        return Vector(self.x + other.x, self.y + other.y)
    def __sub__ (self, other):
        return Vector(self.x - other.x, self.y - other.y)
    def __mul__ (self, other):
        return Vector(self.x * other, self.y * other)
    def __rmul__ (self, other):
        return Vector(self.x * other, self.y * other)
    def __truediv__ (self, other):
        return Vector (self.x /other, self.y /other)
    def getlist(self):
        return [self.x, self.y]
    def angle(self):
        return np.arctan2(self.y, self.x)
    def norm(self):
        if self.x == 0 and self.y == 0:
            return Vector(0,0)
        return self/self.len()
    def dot(self, other):
        return self.x * other.x + self.y * other.y
    def __repr__(self):
        return f'({self.x}, {self.y})'
    
class Tank:
    def __init__(self, name, x, y, ang, nextplayer=None):
        self.angle = np.deg2rad(ang)
        self.position = Vector (x, y)
        self.velocity = Vector(0,0)
        self.width = 40
        self.height = 20
        self.wheelwidth = 5
        self.name = name
        self.health = 100
        self.color = black
        self.direction = Vector(np.cos(self.angle), np.sin(self.angle)).norm()
        self.turretlength = 30
        self.turretend = self.position + self.direction*self.turretlength
        self.turretwidth = 5
        self.nextplayer = nextplayer

    def draw(self):
        pygame.draw.circle(gameDisplay, self.color, self.position.getlist(), self.height/2)
        pygame.draw.rect(gameDisplay, self.color, (self.position.x-self.height, self.position.y, self.width, self.height))
        for i in range(-15, 16, 5):
            pygame.draw.circle(gameDisplay, self.color, (self.position.x - i, self.position.y + 20), self.wheelwidth)
        pygame.draw.line(gameDisplay, self.color, self.position.getlist(), self.turretend.getlist(), self.turretwidth)
    
    def changeangle(self, ang):
        angle = np.deg2rad(ang) + self.direction.angle()
        self.direction = Vector(np.cos(angle), np.sin(angle))
        self.turretend = self.position + self.direction*self.turretlength          

class Projectile:
    def __init__(self, tank):
        assert (isinstance(tank, Tank))
        self.position = tank.turretend
        self.direction = tank.direction
        self.velocity = Vector(0,0)    
        self.tank = tank
        self.acceleration = 0

def text_objects(text, color,size = "small"):
    if size == "small":
        textSurface = smallfont.render(text, True, color)
    if size == "medium":
        textSurface = medfont.render(text, True, color)
    if size == "large":
        textSurface = largefont.render(text, True, color)
    return textSurface, textSurface.get_rect()

class Button:
    def __init__(self, text, x, y, width, height, action):
        self.width, self.height = width, height
        self.x, self.y = x, y
        self.action = action
        self.text = text
        self.clicked = False
    
    def draw(self, active_color, inactive_color):
        self.textsurface= smallfont.render(self.text, True, black)
        self.textrect = self.textsurface.get_rect()
        self.textrect.center = [self.x + self.width/2, self.y + self.height/2]
        pygame.draw.rect(gameDisplay, inactive_color, (self.x,self.y,self.width,self.height))
		#get mouse position
        pos = pygame.mouse.get_pos()
		#check mouseover and clicked conditions
        if self.textrect.collidepoint(pos):
            pygame.draw.rect(gameDisplay, active_color, (self.x,self.y,self.width,self.height))
            if pygame.mouse.get_pressed()[0] == 1 and self.clicked == False:
                self.clicked = True
                if self.action == "quit":
                    pygame.quit()
                    return quit()
                if self.action == "controls":
                    return gamecontrols()
                if self.action == "play":
                    return gameLoop()
                if self.action == "main":
                    return game_intro()
            if pygame.mouse.get_pressed()[0] == 0:
                self.clicked = False
                #draw button on screen
        gameDisplay.blit(self.textsurface, self.textrect)

playb = Button("play", 150, 500, 150, 50,  "play")
rulesb = Button("rules", 350, 500, 150, 50,  "controls")
quitb = Button("quit", 550, 500, 150, 50,  "quit")
mainb = Button("main", 350, 500, 150, 50, "main")

def score(score):
    text = smallfont.render("Score: "+str(score), True, black)
    gameDisplay.blit(text, [0,0])
    

   
def message_to_screen(msg,color, y_displace = 0, size = "small"):
    textSurf, textRect = text_objects(msg,color,size)
    textRect.center = (int(display_width / 2), int(display_height / 2)+y_displace)
    gameDisplay.blit(textSurf, textRect)


def barrier(xlocation,randomHeight, barrier_width):
    pygame.draw.rect(gameDisplay, black, [xlocation, display_height-randomHeight, barrier_width,randomHeight])

def explosion(loc, size=50):
    assert(isinstance(loc, Vector))
    pygame.mixer.Sound.play(explosion_sound)
    explode = True
    while explode:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                quit()
        colorChoices = [red, light_red, yellow, light_yellow]
        magnitude = 1
        while magnitude < size:
            exploding_bit = loc + Vector(random.randrange(-1*magnitude,magnitude), random.randrange(-1*magnitude,magnitude))
            pygame.draw.circle(gameDisplay, colorChoices[random.randrange(0,4)], (exploding_bit.x, exploding_bit.y), random.randrange(1,5))
            magnitude += 1
            pygame.display.update()
            clock.tick(100)
        explode = False

accy = random.randint(5,20)
accx = random.randint(-2,2)

def fireShell(tank1, tank2, gun_power, xlocation,barrier_width,randomHeight, cpin):
    assert(isinstance(tank1, Tank) and isinstance(tank2, Tank))
    pygame.mixer.Sound.play(fire_sound)
    fire = True
    damage = 0
    shell = Projectile(tank1)
    shell.velocity = Vector(shell.direction.x*100*gun_power, shell.direction.y*100*gun_power)
    shell.acceleration = Vector(accx*cpin, accy)

    print("FIRE!", shell.position)
    while fire:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                quit()
        #print(startingShell[0],startingShell[1])
        pygame.draw.circle(gameDisplay, red, shell.position.getlist(),5)
        shell.velocity += shell.acceleration
        shell.position += shell.velocity
        if shell.position.y > display_height - ground_height:
            print("Last shell:", shell.position.x, shell.position.y)
            hit = Vector(int((shell.position.x * display_height-ground_height)/shell.position.y), int(display_height-ground_height))
            print("Impact:", hit.x,hit.y)
            if tank2.position.x + 10 > hit.x > tank2.position.x - 10:
                print("Critical Hit!")
                damage = 25
            elif tank2.position.x + 15 > hit.x > tank2.position.x - 15:
                print("Hard Hit!")
                damage = 18
            elif tank2.position.x + 25 > hit.x > tank2.position.x - 25:
                print("Medium Hit")
                damage = 10
            elif tank2.position.x + 35 > hit.x > tank2.position.x - 35:
                print("Light Hit")
                damage = 5
            explosion(hit)
            fire = False
        check_x_1 = shell.position.x <= xlocation + barrier_width
        check_x_2 = shell.position.x >= xlocation
        check_y_1 = shell.position.y <= display_height
        check_y_2 = shell.position.y >= display_height - randomHeight
        if check_x_1 and check_x_2 and check_y_1 and check_y_2:
            print("Last shell:", shell.position.x, shell.position.y)
            hit = Vector(int((shell.position.x)), int(shell.position.y))
            print("Impact:", hit.x ,hit.y)
            explosion(hit)
            fire = False
        pygame.display.update()
        clock.tick(60)
    return damage

def power(level):
    text = smallfont.render("Power: "+str(int(level*100)),True, black)
    gameDisplay.blit(text, [display_width/2 , 0])

def game_intro():
    intro = True
    while intro:
        for event in pygame.event.get():
                #print(event)
                if event.type == pygame.QUIT:
                    pygame.quit()
                    quit()
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_c:
                        intro = False
                    elif event.key == pygame.K_q:
                        pygame.quit()
                        quit()
        gameDisplay.fill(white)
        message_to_screen("AstroTanks!",green,-100,size="large")
        message_to_screen("Shoot the other tank before it gets you.",black,-30)
        playb.draw(green, light_green)
        rulesb.draw(yellow, light_yellow)
        quitb.draw(red, light_red)
        pygame.display.update()
        clock.tick(15)

def pause():
    paused = True
    message_to_screen("Paused",black,-100,size="large")
    message_to_screen("Press C to continue playing or Q to quit",black,25)
    pygame.display.update()
    while paused:
        for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    quit()
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_c:
                        paused = False
                    elif event.key == pygame.K_q:
                        pygame.quit()
                        quit()
        clock.tick(5)

def gamecontrols():
    gcont = True
    while gcont:
        for event in pygame.event.get():
                #print(event)
            if event.type == pygame.QUIT:
                pygame.quit()
                quit()
        gameDisplay.fill(white)
        message_to_screen("Controls",green,-100,size="large")
        message_to_screen("Fire: Spacebar",black,-30)
        message_to_screen("Move Turret: Up and Down arrows",black,10)
        message_to_screen("Move Tank: Left and Right arrows",black,50)
        message_to_screen("Pause: P",black,130)
        message_to_screen("Control Power: A and D keys", black, 90)
        playb.draw(green, light_green)
        mainb.draw(yellow, light_yellow)
        quitb.draw(red, light_red)
        pygame.display.update()
        clock.tick(15)

def game_over():
    game_over = True
    while game_over:
        for event in pygame.event.get():
                #print(event)
                if event.type == pygame.QUIT:
                    pygame.quit()
                    quit()

        gameDisplay.fill(white)
        message_to_screen("Game Over",green,-100,size="large")
        message_to_screen("You died.",black,-30)
        playb.draw(green, light_green)
        rulesb.draw(yellow, light_yellow)
        quitb.draw(red, light_red)
        pygame.display.update()
        clock.tick(15)

def you_win(player):
    win = True
    while win:
        for event in pygame.event.get():
                #print(event)
                if event.type == pygame.QUIT:
                    pygame.quit()
                    quit()
        gameDisplay.fill(white)
        message_to_screen(f"{player.nextplayer.name} won!",green,-100,size="large")
        message_to_screen("Good Job!",black,-30)
        playb.draw(green, light_green)
        rulesb.draw(yellow, light_yellow)
        quitb.draw(red, light_red)
        pygame.display.update()
        clock.tick(15)

def health_bars(tank1, tank2):
    if tank1.health > 75:
        player_health_color = green
    elif tank1.health > 50:
        player_health_color = yellow
    else:
        player_health_color = red
    if tank2.health > 75:
        enemy_health_color = green
    elif tank2.health > 50:
        enemy_health_color = yellow
    else:
        enemy_health_color = red
    pygame.draw.rect(gameDisplay, player_health_color, (680, 25, tank1.health, 25))
    pygame.draw.rect(gameDisplay, enemy_health_color, (20, 25, tank2.health, 25))

def gameLoop():
    gameExit = False
    gameOver = False
    FPS = 15
    barrier_width = 50
    blue = 	(random.randint(100,255), random.randint(100,255), random.randint(100,255))    
    p1 = Tank('p1', display_width*0.1, display_height * 0.9, 30)
    p2 = Tank('p2', display_width*0.9, display_height * 0.9, 150, p1)
    accy = random.randint(5,20)
    accx = random.randint(-2,0)
    p1.nextplayer = p2
    currentplayer = p1
    fire_power = 0.5
    power_change = 0
    xlocation = (display_width/2) + random.randint(-0.1*display_width, 0.1*display_width) 
    randomHeight = random.randrange(display_height*0.1,display_height*0.6)
    
    while not gameExit: 
        if gameOver == True:
            gameDisplay.fill(white)
            message_to_screen("Game Over",red,-50,size="large")
            message_to_screen("Press C to play again or Q to exit",black,50)
            pygame.display.update()
            while gameOver == True:
                for event in pygame.event.get():
                    if event.type == pygame.QUIT:
                        gameExit = True
                        gameOver = False
                    if event.type == pygame.KEYDOWN:
                        if event.key == pygame.K_c:
                            gameLoop()
                        elif event.key == pygame.K_q:
                            gameExit = True
                            gameOver = False
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                gameExit = True
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_LEFT:
                    currentplayer.velocity.x = -5
                elif event.key == pygame.K_RIGHT:
                    currentplayer.velocity.x = 5
                elif event.key == pygame.K_UP:
                    h = currentplayer.direction.angle()
                    currentplayer.changeangle(h-15) 
                elif event.key == pygame.K_DOWN:
                    h = currentplayer.direction.angle()
                    currentplayer.changeangle(h+15) 
                elif event.key == pygame.K_p:
                    pause()
                elif event.key == pygame.K_SPACE:
                    damage = fireShell(currentplayer, currentplayer.nextplayer, fire_power, xlocation, barrier_width, randomHeight, cpin)
                    currentplayer.health -= damage
                    gameDisplay.fill(green, rect=[0, display_height-ground_height, display_width, ground_height])
                    pygame.display.update()
                    clock.tick(FPS)
                    currentplayer = currentplayer.nextplayer
                elif event.key == pygame.K_a:
                    power_change = -0.01
                elif event.key == pygame.K_d:
                    power_change = 0.01
            elif event.type == pygame.KEYUP:
                if event.key == pygame.K_LEFT or event.key == pygame.K_RIGHT:
                    currentplayer.velocity = Vector(0,0)
                if event.key == pygame.K_UP or event.key == pygame.K_DOWN:
                    h = currentplayer.direction.angle()
                    currentplayer.changeangle(h)                   
                if event.key == pygame.K_a or event.key == pygame.K_d:
                    power_change = 0
        
        currentplayer.position.x += currentplayer.velocity.x
        if currentplayer.direction.angle() > 270:
            currentplayer.changeangle(180)
        elif currentplayer.direction.angle() < 90:
            currentplayer.changeangle(0)
        
        if currentplayer == p1:
            cpin = 1
        else:
            cpin = -1

        if currentplayer == p1:
            if currentplayer.position.x - (currentplayer.width/2) > (xlocation - barrier_width):
                currentplayer.position.x -= 5
        else:
            if currentplayer.position.x - (currentplayer.width/2) < (xlocation + barrier_width):
                currentplayer.position.x += 5
            

        gameDisplay.fill(blue)
        health_bars(p1,p2)
        p1.draw()
        p2.draw()
       
        fire_power += power_change

        if fire_power > 1:
            fire_power = 1
        elif fire_power < 0:
            fire_power = 0         
        
        power(fire_power)
        barrier(xlocation,randomHeight,barrier_width)
        gameDisplay.fill(green, rect=[0, display_height-ground_height, display_width, ground_height])
        pygame.display.update()

        if currentplayer.health < 1:
            you_win(currentplayer.nextplayer)
        elif currentplayer.nextplayer.health < 1:
            you_win(currentplayer)
        clock.tick(FPS)

    pygame.quit()
    quit()

game_intro()
gameLoop()